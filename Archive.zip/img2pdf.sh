#!/bin/zsh

# Преобразовывает снимок экрана веб-страницы (например, 600x6000 px) в многостраничный PDF
# ./<скрипт> <изображение>

# 8.5 x 11   ANSI A, aka Letter
# 5.5 x 8.5  Half Letter
# 9   x 12   Arch A
# 6   x 9    US Trade

paperwidth=8.5; paperheight=11
marginsleftright=1; marginstopbottom=1

marginsleftright=${$(( marginsleftright*300 ))%.}
marginstopbottom=${$(( marginstopbottom*300 ))%.}
columnwidth=${$(( paperwidth*300 - marginsleftright*2 ))%.}
columnheight=${$(( paperheight*300 - marginstopbottom*2 ))%.}

magick "$1" +repage -resize ${columnwidth}x\> \
  -crop x${columnheight} +repage \
  -background white -extent ${columnwidth}x${columnheight} \
  -bordercolor white -border ${marginsleftright}x${marginstopbottom} \
  -units PixelsPerInch -density 300 "${1%.*}.pdf"
