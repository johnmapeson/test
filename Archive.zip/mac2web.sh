#!/bin/zsh

# Изменяет размер и расширение сделанного на Mac снимка экрана,
# чтобы он отображался в веб-браузере в правильном размере
# ./<скрипт> <изображение>

densityX=$(magick identify -format "%x" "$1" | sed 's/[^0-9.]//g')
densityY=$(magick identify -format "%y" "$1" | sed 's/[^0-9.]//g')

if (( $(echo "$densityX > 72" | bc -l) || $(echo "$densityY > 72" | bc -l) )); then
  width=$(magick identify -format "%w" "$1")
  height=$(magick identify -format "%h" "$1")

  newWidth=$(echo "$width * 72 / $densityX" | bc)
  newHeight=$(echo "$height * 72 / $densityY" | bc)

  base="${1%.*}"
  ext="${1##*.}"
  output="${base}_web.${ext}"

  magick "$1" -sample "${newWidth}x${newHeight}" \
         -units PixelsPerInch -density 72 "$output"
fi
