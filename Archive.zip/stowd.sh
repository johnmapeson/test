#!/bin/sh

# "This trivial thing just uses GNU Stow to symlink all *directories*,
# meaning there's no need to blacklist README or any other top-level
# files."
# https://github.com/faho/config

if ! command -v stow > /dev/null 2>&1 ; then
    echo "Install gnu stow"
    exit 1
fi

for d in ~/.config/*; do
    [ ! -d "$d" ] && continue
    stow -S -t "$HOME" "$d"
done
