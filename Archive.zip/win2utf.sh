#!/bin/zsh

# Исправляет кракозябры в именах перемещённых с Windows файлов
# ./<скрипт> <папка с файлами>

perl -MFile::Rename -e 1 2>/dev/null || {
  echo "Error: Perl module File::Rename is not installed." >&2
  exit 1
}

rename_all=0

find "$@" -mindepth 1 -depth -print0 |
  rename -0 -d -e "
    use Unicode::Normalize qw(NFC);
    use Encode qw(:all);
    use utf8;

    my \$rename_all = $rename_all;
    my \$check = DIE_ON_ERR | LEAVE_SRC;
    my \$new = eval { NFC(decode('UTF-8', \$_, \$check)) };

    if (\$new) {
      if (\$rename_all || \$new =~ /[
        \N{DAGGER}
        \N{DEGREE SIGN}
        \N{CYRILLIC CAPITAL LETTER GHE WITH UPTURN}
        \N{POUND SIGN}
        \N{SECTION SIGN}
        \N{BULLET}
        \N{PILCROW SIGN}
        \N{CYRILLIC CAPITAL LETTER BYELORUSSIAN-UKRAINIAN I}
        \N{REGISTERED SIGN}
        \N{COPYRIGHT SIGN}
        \N{TRADE MARK SIGN}
        \N{CYRILLIC CAPITAL LETTER DJE}
        \N{CYRILLIC SMALL LETTER DJE}
        \N{NOT EQUAL TO}
      ]/) {
        \$new = eval {
          encode('UTF-8',
            decode('cp866',
              encode('mac-cyrillic', \$new, \$check), \$check))
        };
        if (\$new) { \$_ = \$new; } else { warn \$@; }
      }
    } else {
      warn \$@;
    }
  "
