#!/bin/zsh

echo foo
