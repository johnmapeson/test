#!/bin/zsh

echo bar
