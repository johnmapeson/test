#!/bin/zsh

echo ccc
