#!/bin/zsh

echo ddd
